#include <stdio.h> // Biblioteca padrão para entrada e saída
#include <stdlib.h> // Biblioteca para funções úteis, como alocação de memória
#include <math.h> // Biblioteca para cálculos matemáticos (ex.: potência)
#include <windows.h> // Biblioteca específica do Windows (ex.: medição de tempo)
#include <time.h> // Biblioteca para manipulação de tempo

#define MAX_CONFIGURATIONS 81 // Total de configurações possíveis (3^4 = 81)
#define INF 1000000 // Valor que representa "infinito" no algoritmo de Dijkstra
// O infinito é usado para inicializar a distância de todos os nós, exceto o nó inicial, 
// já que no início do algoritmo não sabemos o caminho para esses nós. 
// Isso garante que qualquer distância calculada durante o algoritmo será menor que INF.


// Estrutura que armazena uma configuração dos discos
typedef struct
{
    int disks[4]; // Posições dos 4 discos (valores de 0 a 2, que representam os pinos)
} Configuration;

// Função para medir o tempo em nanosegundos
double getTime()
{
    LARGE_INTEGER frequency, start;
    QueryPerformanceFrequency(&frequency); // Frequência do contador de alta precisão
    QueryPerformanceCounter(&start); // Valor atual do contador
    return (double)start.QuadPart / frequency.QuadPart * 1e9; // Retorna o tempo em nanosegundos
}

// Função para gerar todas as 81 configurações possíveis de discos
void generateConfigurations(Configuration *configs)
{
    int i, j;

    // Para cada número de configuração (de 0 a 80)
    for (i = 0; i < MAX_CONFIGURATIONS; i++)
    {
        // Calcula a posição de cada disco (base 3)
        for (j = 0; j < 4; j++)
        {
            configs[i].disks[j] = (i / (int)pow(3, j)) % 3; // Converte o número para base 3
        }
    }
}

// Função para exibir todas as configurações geradas
void displayConfigurations(Configuration *configs)
{
    int i, j;

    printf("\nTodas as configurações:\n");
    for (i = 0; i < MAX_CONFIGURATIONS; i++) // Percorre todas as configurações
    {
        printf("Configuração %d: ", i); // Número da configuração
        for (j = 0; j < 4; j++) // Exibe as posições dos 4 discos
        {
            printf("%d ", configs[i].disks[j] + 1); // Ajusta para exibir valores entre 1 e 3
        }
        printf("\n"); // Nova linha para a próxima configuração
    }
}

// Função para verificar se é possível mover de uma configuração para outra
int isValidMove(Configuration a, Configuration b)
{
    int diffCount = 0; // Conta quantos discos mudaram de posição
    int from = -1, to = -1; // Pino de onde o disco foi retirado e para onde foi colocado
    int smallestDisk = -1; // Índice do menor disco movido
    int isValid = 1; // Assume que o movimento é válido
    int i;

    // Verifica quais discos mudaram de posição
    for (i = 0; i < 4; i++)
    {
        if (a.disks[i] != b.disks[i]) // Mudança detectada
        {
            diffCount++; // Incrementa o número de diferenças

            if (diffCount > 1) // Mais de um disco mudou? Movimento inválido
            {
                isValid = 0;
                break;
            }
            else
            {
                from = a.disks[i]; // Guarda o pino de origem
                to = b.disks[i]; // Guarda o pino de destino
                smallestDisk = i; // Salva o índice do disco movido
            }
        }
    }

    // Se nenhum ou mais de um disco mudou, o movimento é inválido
    if (diffCount != 1)
    {
        isValid = 0;
    }

    // Verifica se algum disco menor impede o movimento
    i = 0;
    while (i < smallestDisk && isValid)
    {
        if (a.disks[i] == from || b.disks[i] == to) // Bloqueio detectado
        {
            isValid = 0;
        }
        i++;
    }

    return isValid; // Retorna se o movimento é válido ou não
}

// Função que cria o grafo de configurações possíveis
void buildGraph(int graph[MAX_CONFIGURATIONS][MAX_CONFIGURATIONS], Configuration *configs)
{
    int i, j;

    // Para cada par de configurações, verifica se é possível ir de uma para a outra
    for (i = 0; i < MAX_CONFIGURATIONS; i++)
    {
        for (j = 0; j < MAX_CONFIGURATIONS; j++)
        {
            // Se o movimento entre as configurações é válido, peso = 1, caso contrário, INF
            graph[i][j] = isValidMove(configs[i], configs[j]) ? 1 : INF;
        }
    }
}

// Algoritmo de Dijkstra para encontrar o menor caminho entre duas configurações
void dijkstra(int graph[MAX_CONFIGURATIONS][MAX_CONFIGURATIONS], int start, int end, Configuration *configs)
{
    int dist[MAX_CONFIGURATIONS], prev[MAX_CONFIGURATIONS], visited[MAX_CONFIGURATIONS] = {0};
    int i, j, v, at;

    // Inicializa as distâncias como infinito, e o nó inicial com distância 0
    for (i = 0; i < MAX_CONFIGURATIONS; i++)
    {
        dist[i] = INF;
        prev[i] = -1;
    }
    dist[start] = 0;

    // Loop principal do algoritmo
    for (i = 0; i < MAX_CONFIGURATIONS; i++)
    {
        int minDist = INF, u = -1;

        // Encontra o próximo nó não visitado com menor distância
        for (j = 0; j < MAX_CONFIGURATIONS; j++)
        {
            if (!visited[j] && dist[j] < minDist)
            {
                minDist = dist[j];
                u = j;
            }
        }

        if (u == -1) // Nenhum nó acessível
            break;

        visited[u] = 1; // Marca o nó como visitado

        // Atualiza as distâncias dos vizinhos
        for (v = 0; v < MAX_CONFIGURATIONS; v++)
        {
            if (graph[u][v] != INF && dist[u] + graph[u][v] < dist[v])
            {
                dist[v] = dist[u] + graph[u][v];
                prev[v] = u; // Salva o nó anterior no caminho
            }
        }
    }

    // Exibe o menor caminho encontrado
    printf("Menor caminho do início ao final: %d movimentos\n", dist[end]);

    // Reconstrói o caminho
    int path[MAX_CONFIGURATIONS], pathIndex = 0;
    for (at = end; at != -1; at = prev[at])
    {
        path[pathIndex++] = at;
    }

    // Exibe o caminho reconstruído
    for (i = pathIndex - 1; i >= 0; i--)
    {
        printf("Configuração %d: [", path[i]);
        for (j = 0; j < 4; j++)
        {
            printf("%d", configs[path[i]].disks[j] + 1);
            if (j < 3)
                printf(", ");
        }
        printf("]\n");
    }
}

// Função principal que controla o programa
int main()
{
    Configuration configs[MAX_CONFIGURATIONS]; // Lista de todas as configurações
    int graph[MAX_CONFIGURATIONS][MAX_CONFIGURATIONS]; // Matriz de adjacência do grafo
    int choice, start, end; // Opções e configurações inicial/final
    double startTime, endTime; // Para medir o tempo de execução

    generateConfigurations(configs); // Gera todas as configurações possíveis
    buildGraph(graph, configs); // Cria o grafo com os movimentos válidos

    // Menu interativo
    do
    {
        printf("\n========== MENU ==========\n");
        printf("1. Exibir todas as configurações\n");
        printf("2. Calcular o menor caminho entre duas configurações\n");
        printf("3. Sair\n");
        printf("==========================\n");
        printf("Escolha uma opção: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            displayConfigurations(configs); // Exibe todas as configurações
            break;
        case 2:
            printf("Digite a configuração inicial (0 a 80): ");
            scanf("%d", &start);
            printf("Digite a configuração final (0 a 80): ");
            scanf("%d", &end);

            startTime = getTime(); // Tempo inicial
            dijkstra(graph, start, end, configs); // Calcula o menor caminho
            endTime = getTime(); // Tempo final

            printf("Tempo gasto: %.2lf nanosegundos\n", endTime - startTime);
            break;
        case 3:
            printf("Saindo...\n");
            break;
        default:
            printf("Opção inválida!\n");
        }
    } while (choice != 3);

    return 0;
}
/*
    OBJETIVO DO CÓDIGO:
    Este programa resolve e analisa um problema relacionado à Torre de Hanói.
    Ele utiliza conceitos de grafos para representar todas as possíveis configurações de discos
    em três pinos e encontra o menor número de movimentos necessários para ir de uma configuração inicial
    a uma configuração final.

    FUNCIONALIDADES PRINCIPAIS:
    1. Gera todas as 81 configurações possíveis de 4 discos distribuídos em 3 pinos.
    2. Verifica quais movimentos entre configurações são válidos, respeitando as regras do problema.
    3. Constrói um grafo, onde:
       - Cada vértice é uma configuração.
       - Cada aresta representa um movimento válido entre configurações.
    4. Utiliza o algoritmo de Dijkstra para encontrar o menor caminho entre duas configurações.
    5. Exibe o menor número de movimentos necessários e o caminho (sequência de configurações).
    
    POSSÍVEIS APLICAÇÕES:
    - Simulações de resolução do problema da Torre de Hanói.
    - Ensino de algoritmos de grafos (Dijkstra, construção de grafos).
    - Análise de combinações e otimização em problemas similares.
*/


/* 
    Por que usamos o algoritmo de Dijkstra?

    1. **Arestas com pesos positivos**:
       - Todas as arestas no grafo têm peso positivo (1 ou INF).
       - O Dijkstra é otimizado para encontrar o menor caminho em grafos com pesos positivos.
       - O Bellman-Ford é necessário apenas quando existem arestas com pesos negativos, o que não é o caso aqui.

    2. **Eficiência**:
       - O Dijkstra tem complexidade O(V + E * log(V)) quando implementado com uma fila de prioridade.
       - O Bellman-Ford, por outro lado, tem complexidade O(V * E), tornando-o mais lento em grafos densos como este.

    3. **Menor caminho com pesos uniformes**:
       - Como todas as arestas válidas têm peso 1, o Dijkstra consegue encontrar o menor número de movimentos de forma rápida e eficiente.

    Resumo:
    O algoritmo de Dijkstra é a melhor escolha para este problema porque é mais eficiente e adequado para grafos com arestas de peso positivo e uniforme.
*/


// Struct Configuration
// Estrutura que representa uma configuração do problema.
// O array `disks[4]` armazena o estado dos 4 discos, onde:
// - Cada posição do array representa um disco (0 a 3).
// - O valor na posição indica em qual torre o disco está (0, 1 ou 2).

// Função getTime()
// Retorna o tempo atual em nanosegundos.
// - `QueryPerformanceFrequency`: Obtém a frequência do contador de alta precisão.
// - `QueryPerformanceCounter`: Lê o valor atual do contador.
// - Divide o valor lido pela frequência para obter o tempo decorrido em segundos e converte para nanosegundos.
// Usada para medir o desempenho e o tempo de execução de algoritmos.


// Função generateConfigurations(Configuration *configs)
// Gera todas as configurações possíveis de discos e as armazena no array `configs`.
// - Para cada configuração `i` (0 a 80):
//   1. Para cada disco (0 a 3), calcula sua posição usando `(i / pow(3, j)) % 3`.
//      - `pow(3, j)`: Obtém o peso da base 3 para o disco `j`.
//      - `(i / pow(3, j))`: Isola o dígito correspondente ao disco `j` na representação na base 3.
//      - `% 3`: Obtém o valor do dígito (0, 1 ou 2), que representa a torre do disco.
// - Resultado: Cada configuração representa uma distribuição válida de discos em 3 torres.


// Função displayConfigurations(Configuration *configs)
// Imprime todas as 81 configurações armazenadas no array `configs`.
// - Para cada configuração:
//   1. Imprime o número da configuração (`i`).
//   2. Itera pelos 4 discos e imprime o estado de cada disco, adicionando 1 para exibir como (1, 2, 3).


// Função isValidMove(Configuration a, Configuration b)
// Verifica se é possível mover de uma configuração `a` para outra `b` respeitando as regras do jogo.
// Passo a passo:
// 1. Calcula quantos discos mudaram de posição entre `a` e `b`.
//    - Se mais de um disco mudou, o movimento é inválido (`diffCount > 1`).
// 2. Identifica de onde (from) e para onde (to) o disco foi movido.
// 3. Verifica se o disco movido é o menor disponível na torre original (não pode haver outro disco menor bloqueando).
// 4. Verifica se o disco movido não foi colocado em uma torre acima de outro disco menor.
// Retorna:
// - `1` (válido) se as regras forem seguidas.
// - `0` (inválido) caso contrário.


// Função buildGraph(int graph[MAX_CONFIGURATIONS][MAX_CONFIGURATIONS], Configuration *configs)
// Constrói a matriz de adjacência do grafo representando todas as configurações possíveis.
// - Para cada par de configurações `(i, j)`:
//   1. Verifica se é possível mover de `i` para `j` usando `isValidMove`.
//   2. Se for válido, define `graph[i][j] = 1`.
//   3. Caso contrário, define `graph[i][j] = INF` (representando caminho impossível).
// Resultado: Um grafo onde os vértices são as configurações e as arestas representam movimentos válidos.


// Função dijkstra(...)
// Implementa o algoritmo de Dijkstra para encontrar o menor caminho entre duas configurações.
// Entrada:
// - `graph`: Matriz de adjacência com os pesos das arestas (1 para movimentos válidos, `INF` para inválidos).
// - `start`: Índice da configuração inicial.
// - `end`: Índice da configuração final.
// Passo a passo:
// 1. Inicializa as distâncias (`dist`) de todos os vértices como `INF`, exceto o inicial (`dist[start] = 0`).
// 2. Cria um vetor de visitados para rastrear os vértices já processados.
// 3. Iterativamente:
//    - Escolhe o vértice `u` não visitado com a menor distância (`dist[u]`).
//    - Marca `u` como visitado.
//    - Atualiza as distâncias dos vizinhos de `u`:
//      - Se `dist[u] + graph[u][v] < dist[v]`, atualiza `dist[v]` e define `prev[v] = u`.
// 4. Reconstrói o menor caminho do final (`end`) ao início (`start`) usando o vetor de predecessores (`prev`).
// 5. Imprime o menor caminho e a sequência de configurações no trajeto.
// Por que usar `INF`?
// - Indica caminhos impossíveis e evita que sejam considerados no cálculo do menor caminho.


// Função main()
// Controla o fluxo do programa com um menu interativo.
// Opções:
// 1. Exibe todas as configurações possíveis (usando `displayConfigurations`).
// 2. Calcula o menor caminho entre duas configurações (usando `dijkstra`):
//    - Lê as configurações inicial e final do usuário.
//    - Mede o tempo de execução para calcular o menor caminho.
// 3. Encerra o programa.
