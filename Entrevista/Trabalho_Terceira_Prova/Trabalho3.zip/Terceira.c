#include <stdio.h>   // Biblioteca padrão para entrada e saída (ex.: printf, scanf)
#include <stdlib.h>  // Biblioteca para alocação de memória e funções auxiliares
#include <math.h>    // Biblioteca matemática (ex.: log, exp)
#include <float.h>   // Biblioteca para constantes relacionadas a números de ponto flutuante (ex.: DBL_MAX)

#define MAX_VERTICES 100 // Número máximo de vértices permitido no grafo
#define INF DBL_MAX      // Valor que representa "infinito" para distâncias inicialmente desconhecidas

// Estrutura que representa uma aresta do grafo
typedef struct {
    int v;         // Vértice de destino da aresta
    double weight; // Peso da aresta, calculado como -log(reliability)
} Edge;

// Estrutura que representa o grafo
typedef struct {
    Edge edges[MAX_VERTICES][MAX_VERTICES]; // Matriz de adjacência para armazenar as arestas
    int numVertices;                        // Número total de vértices no grafo
    int numEdges;                           // Número total de arestas no grafo
} Graph;

/* 
Função: initGraph
Propósito:
- Inicializa o grafo, configurando todas as arestas como "infinito" (`INF`), exceto para loops (peso 0 para vértices ligados a si mesmos).

Funcionamento:
1. Recebe o grafo (`g`) e o número de vértices (`numVertices`).
2. Define todas as arestas como "infinito", indicando que inicialmente não existem conexões entre os vértices.
3. Define peso 0 para arestas reflexivas (ex.: de `i` para `i`).
4. Inicializa o número total de arestas (`numEdges`) como 0.
*/
void initGraph(Graph *g, int numVertices) {
    g->numVertices = numVertices; // Configura o número de vértices no grafo
    g->numEdges = 0;              // Inicializa o número de arestas como zero

    for (int i = 0; i < numVertices; i++) {
        for (int j = 0; j < numVertices; j++) {
            g->edges[i][j].weight = (i == j) ? 0.0 : INF; // Peso 0 para loops, INF para outros
        }
    }
}

/* 
Função: addEdge
Propósito:
- Adiciona uma aresta direcionada entre dois vértices, calculando o peso com base na confiabilidade.

Funcionamento:
1. Verifica se o valor de confiabilidade está no intervalo (0, 1].
   - Caso contrário, exibe um erro e encerra o programa.
2. Calcula o peso da aresta como `-log(reliability)`. Isso transforma multiplicações de probabilidades em somas, que podem ser manipuladas pelo algoritmo de Dijkstra.
3. Atualiza a matriz de adjacência com o peso da aresta.
4. Incrementa o contador de arestas do grafo.
*/
void addEdge(Graph *g, int u, int v, double reliability) {
    if (reliability <= 0 || reliability > 1) { // Valida o intervalo da confiabilidade
        printf("Erro: Confiabilidade deve estar no intervalo (0, 1].\n");
        exit(1);
    }

    g->edges[u][v].v = v;                    // Configura o vértice de destino
    g->edges[u][v].weight = -log(reliability); // Calcula o peso da aresta
    g->numEdges++;                           // Incrementa o número de arestas
}

/* 
Função: dijkstra
Propósito:
- Encontra o caminho mais confiável entre dois vértices em um grafo ponderado.

Funcionamento:
1. **Inicialização:**
   - Define as distâncias mínimas (`dist`) como infinito (`INF`), exceto para o vértice inicial (`start`), que tem distância 0.
   - O vetor `prev` armazena os predecessores de cada vértice no menor caminho.
   - O vetor `visited` rastreia os vértices já processados.

2. **Execução do algoritmo:**
   - Itera sobre os vértices, escolhendo aquele com a menor distância ainda não visitado.
   - Para cada vizinho desse vértice, calcula a nova distância acumulada considerando o peso da aresta.
   - Se a nova distância for menor que a atual registrada, atualiza a distância e o predecessor.

3. **Reconstrução do caminho:**
   - Usa o vetor `prev` para rastrear o caminho do vértice final (`end`) até o inicial (`start`).
   - O caminho é construído de trás para frente e invertido para exibição.

4. **Cálculo da probabilidade:**
   - A probabilidade total do caminho é calculada como `exp(-dist[end])`, que reverte a transformação logarítmica.
*/
void dijkstra(Graph *g, int start, int end, int *path, double *probability) {
    double dist[MAX_VERTICES];       // Distância mínima conhecida de cada vértice ao vértice inicial
    int prev[MAX_VERTICES];          // Array para armazenar o predecessor de cada vértice
    int visited[MAX_VERTICES] = {0}; // Marca os vértices já processados
    int n = g->numVertices;          // Número de vértices no grafo

    // Inicialização
    for (int i = 0; i < n; i++) {
        dist[i] = INF; // Todas as distâncias começam como infinito
        prev[i] = -1;  // Nenhum predecessor conhecido
    }
    dist[start] = 0.0; // A distância inicial é 0

    // Execução do algoritmo
    for (int i = 0; i < n; i++) {
        double minDist = INF; // Menor distância encontrada para um vértice não visitado
        int u = -1;

        // Encontra o vértice não visitado com menor distância
        for (int j = 0; j < n; j++) {
            if (!visited[j] && dist[j] < minDist) {
                minDist = dist[j];
                u = j;
            }
        }

        // Se nenhum vértice acessível for encontrado, encerra
        if (u == -1) break;

        visited[u] = 1; // Marca o vértice como visitado

        // Atualiza as distâncias para os vizinhos de `u`
        for (int v = 0; v < n; v++) {
            if (!visited[v] && g->edges[u][v].weight < INF) {
                double newDist = dist[u] + g->edges[u][v].weight; // Calcula a nova distância
                if (newDist < dist[v]) { // Se a nova distância for menor
                    dist[v] = newDist; // Atualiza a menor distância
                    prev[v] = u;       // Define o predecessor
                }
            }
        }
    }

    // Reconstrói o caminho
    int current = end;
    int pathIndex = 0;
    while (current != -1) { // Segue os predecessores até o início
        path[pathIndex++] = current;
        current = prev[current];
    }

    // Inverte o caminho para exibição
    for (int i = 0; i < pathIndex / 2; i++) {
        int temp = path[i];
        path[i] = path[pathIndex - 1 - i];
        path[pathIndex - 1 - i] = temp;
    }

    path[pathIndex] = -1; // Marca o final do caminho

    // Calcula a probabilidade total do caminho
    *probability = exp(-dist[end]);
}

/* 
Função: main
Propósito:
- Controla o fluxo do programa, permitindo ao usuário interagir com o grafo e calcular caminhos.

Funcionamento:
1. Solicita o número de vértices e arestas do grafo.
2. Inicializa o grafo e lê as arestas, validando as entradas.
3. Solicita os vértices de origem e destino para calcular o caminho mais confiável.
4. Exibe o caminho mais confiável e a probabilidade total.
5. Oferece a opção de executar novamente ou sair.
*/
int main() {
    Graph g; // Declaração do grafo
    int repeat = 1;

    while (repeat) {
        int n, m;

        printf("Digite o numero de vertices e arestas: ");
        if (scanf("%d %d", &n, &m) != 2 || n <= 0 || m < 0 || n > MAX_VERTICES) {
            printf("Erro: Entrada invalida para vertices ou arestas.\n");
            continue;
        }

        initGraph(&g, n); // Inicializa o grafo

        printf("Digite as arestas no formato (u v r):\n");
        for (int i = 0; i < m; i++) {
            int u, v;
            double r;
            if (scanf("%d %d %lf", &u, &v, &r) != 3 || u < 0 || v < 0 || u >= n || v >= n || r <= 0 || r > 1) {
                printf("Erro: Entrada invalida para arestas.\n");
                i--; // Permite tentar novamente
            } else {
                addEdge(&g, u, v, r); // Adiciona a aresta
            }
        }

        int start, end;
        printf("Digite os vertices de origem e destino: ");
        if (scanf("%d %d", &start, &end) != 2 || start < 0 || end < 0 || start >= n || end >= n) {
            printf("Erro: Entrada invalida para origem ou destino.\n");
            continue;
        }

        int path[MAX_VERTICES] = {-1};
        double probability;
        dijkstra(&g, start, end, path, &probability);

        printf("Caminho mais confiavel: ");
        for (int i = 0; path[i] != -1; i++) {
            printf("%d ", path[i]);
        }
        printf("\nProbabilidade de sucesso total: %.2lf%%\n", probability * 100);

        printf("Deseja calcular novamente? (1 - Sim / 0 - Nao): ");
        if (scanf("%d", &repeat) != 1) repeat = 0;
    }

    return 0;
}
