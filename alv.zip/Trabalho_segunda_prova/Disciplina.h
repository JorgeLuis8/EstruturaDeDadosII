typedef struct Arv_Disciplina arv_disciplina;

arv_disciplina *cria_no();