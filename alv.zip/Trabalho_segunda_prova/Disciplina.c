#include <stdio.h>
#include <stdlib.h>
#include "Disciplina.h"

#define RED 0
#define BLACK 1

typedef struct Dados{
    int codigo;
    char nome[50];
    int bloco;
    int carga_horaria;
}dados;


typedef struct Arv_Disciplina
{
    struct Dados *dados;
    int cor;
    struct Curso *raiz;
    struct Curso *esq, *dir;

}arv_disciplina;

arv_disciplina * cria_no(){
    arv_disciplina *no = (arv_disciplina*) malloc(sizeof(arv_disciplina));
    no->cor = RED;
    no->esq = NULL;
    no->dir = NULL;
    return no;
}
