typedef struct plataforma Plataforma;
